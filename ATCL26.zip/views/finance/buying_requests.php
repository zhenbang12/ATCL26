<?php
// Buying requests listing with simple create form
?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Buying Requests</h2>
</div>

<form method="post" action="/finance/buying-requests/store" enctype="multipart/form-data" class="row g-3 mb-4">
    <div class="col-md-3">
        <label class="form-label">Requester</label>
        <input type="text" name="requester_name" class="form-control" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Department</label>
        <input type="text" name="department" class="form-control" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Quantity</label>
        <input type="number" name="quantity" class="form-control" value="1" min="1" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Estimated Cost</label>
        <input type="number" step="0.01" name="estimated_cost" class="form-control" required>
    </div>
    <div class="col-md-12">
        <label class="form-label">Item Description</label>
        <textarea name="item_description" class="form-control" rows="2" required></textarea>
    </div>
    <div class="col-md-6">
        <label class="form-label">Justification</label>
        <textarea name="justification" class="form-control" rows="2" placeholder="Why is this purchase needed?"></textarea>
    </div>
    <div class="col-md-6">
        <label class="form-label">Vendor Preference (Optional)</label>
        <input type="text" name="vendor_preference" class="form-control" placeholder="Preferred vendor name">
    </div>
    <div class="col-md-12">
        <label class="form-label">Reference Image</label>
        <input type="file" name="reference_image" class="form-control" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp">
        <small class="text-muted">Max 5MB. Accepted formats: JPEG, PNG, GIF, WebP</small>
    </div>
    <div class="col-12">
        <button type="submit" class="btn btn-primary btn-sm">Submit Request</button>
    </div>
</form>

<table class="table table-sm table-striped">
    <thead>
    <tr>
        <th>Requester</th>
        <th>Dept</th>
        <th>Item Description</th>
        <th>Qty</th>
        <th>Cost</th>
        <th>Vendor</th>
        <th>Image</th>
        <th>Status</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($buyingRequests as $br): ?>
        <tr>
            <td><?= htmlspecialchars($br['requester_name']) ?></td>
            <td><?= htmlspecialchars($br['department']) ?></td>
            <td>
                <div><?= htmlspecialchars($br['item_description']) ?></div>
                <?php if (!empty($br['justification'])): ?>
                    <small class="text-muted"><?= htmlspecialchars($br['justification']) ?></small>
                <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($br['quantity']) ?></td>
            <td class="text-end"><?= number_format((float)$br['estimated_cost'], 2) ?></td>
            <td><?= htmlspecialchars($br['vendor_preference'] ?? '-') ?></td>
            <td>
                <?php if (!empty($br['reference_image'])): ?>
                    <img src="<?= htmlspecialchars($br['reference_image']) ?>" 
                         alt="Reference" 
                         class="img-thumbnail" 
                         style="max-width: 100px; max-height: 100px; cursor: pointer; object-fit: cover;"
                         onclick="showImageModal('<?= htmlspecialchars($br['reference_image']) ?>', 'Reference Image')">
                <?php else: ?>
                    <span class="text-muted">-</span>
                <?php endif; ?>
            </td>
            <td>
                <?php
                $statusColors = [
                    'pending' => 'warning',
                    'approved' => 'success',
                    'rejected' => 'danger',
                    'purchased' => 'info'
                ];
                $color = $statusColors[$br['status']] ?? 'secondary';
                ?>
                <span class="badge bg-<?= $color ?>"><?= ucfirst($br['status']) ?></span>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<!-- Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imageModalLabel">Image</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <img id="modalImage" src="" alt="" class="img-fluid" style="max-height: 70vh;">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <a id="modalImageLink" href="" target="_blank" class="btn btn-primary">Open in New Tab</a>
            </div>
        </div>
    </div>
</div>

<script>
function showImageModal(imageSrc, title) {
    const modal = new bootstrap.Modal(document.getElementById('imageModal'));
    document.getElementById('imageModalLabel').textContent = title;
    document.getElementById('modalImage').src = imageSrc;
    document.getElementById('modalImage').alt = title;
    document.getElementById('modalImageLink').href = imageSrc;
    modal.show();
}
</script>
